var express = require('express');
var hhtp = require('http');
var app = express();
var MongoClient = require('mongodb').MongoClient;
var assert = require('assert');
var ObjectId = require('mongodb').ObjectID;
var url = 'mongodb://localhost:27017/maBase';



var findProducts = function (db,search,callback){
					var cursor = db.collection('Produits').find(search);
					var resultat = [];
					cursor.each(function(err,doc){
				        	assert.equal(null,err);
						if (doc != null){
							resultat.push(doc);
							for (var p in doc){
							console.log(p+"   :    "+doc[p]);
							}
						}
						else {callback(resultat);}
						console.log("\n");
					});
};

var findProductsTypes = function (db,callback){
db.collection('Produits').distinct('type',function(err, cursor) {
		if (cursor != null){
			for (var p in cursor){
			console.log(p+"   :    "+cursor[p]);
			}
		}
		else {callback(cursor);console.log("Je bloque làelse");}
		console.log("\n");
		console.log("Je bloque là");

});
};

				var findProductsPanier = function (db,search,callback){
										var cursor = db.collection('Panier').find(search);
										var resultat = [];
										cursor.each(function(err,doc){
									        	assert.equal(null,err);
											if (doc != null){
												resultat.push(doc);
												for (var p in doc){
												console.log(p+"   :    "+doc[p]);
												}
											}
											else {callback(resultat);}
											console.log("\n");
										});
};
var insertProductsPanier = function (db,search,callback){
			var cursor = db.collection('Panier').insert(search);
			var resultat = [];
			cursor.each(function(err,doc){
							assert.equal(null,err);
				if (doc != null){
					resultat.push(doc);
					for (var p in doc){
					console.log(p+"   :    "+doc[p]);
					}
				}
				else {callback(resultat);}
				console.log("\n");
			});
};


MongoClient.connect(url,function(err,db){

	assert.equal(null,err);
	app.get('/products/types/:type',function(req,res){
				var typeAChercher = req.params.type;
				console.log("////serveur node : /products/types/"+typeAChercher);
				var search = {"type" : typeAChercher};
				findProducts(db,search, function(ProductSearch){
					res.setHeader('Access-Control-Allow-Origin','*');
					res.setHeader('Content-Type','application/json');
					var json = JSON.stringify(ProductSearch);
					res.end(json);
	  			})
	});

	app.get('/products/marque/:marque',function(req,res){
				var marqueAChercher = req.params.marque;
				console.log("serveur node : /products/marque/"+marqueAChercher);
				var search = {"marque" : marqueAChercher};
				findProducts(db,search, function(ProductSearch){
					res.setHeader('Access-Control-Allow-Origin','*');
					res.setHeader('Content-Type','application/json');
					var json = JSON.stringify(ProductSearch);
					res.end(json);
	  			})
	});


	app.get('/products/panier/afficher/',function(req,res){
				//var marqueAChercher = req.params.marque;
				console.log("Accès panier");
				var search = {};
				findProductsPanier(db,search, function(ProductSearch){
					res.setHeader('Access-Control-Allow-Origin','*');
					res.setHeader('Content-Type','application/json');
					var json = JSON.stringify(ProductSearch);
					res.end(json);
	  			})
	});

	app.get('/products/panier/ajouter/:id',function(req,res){
				var idAChercher = req.params.id;
				console.log("serveur node : /products/panier/ajouter/"+idAChercher);
				var product = {_id : ObjectId(""+idAChercher)};
				console.log(product);
				findProducts(db,product, function(ProductSearch){
					res.setHeader('Access-Control-Allow-Origin','*');
					res.setHeader('Content-Type','application/json');
					var json = JSON.stringify(ProductSearch);
					db.collection('Panier').insert(ProductSearch);
					console.log(json);
					res.end(json);

					})
	});
	app.get('/products/panier/supprimer/:id',function(req,res){
				var idASupprimer = req.params.id;
				console.log("serveur node : /products/panier/supprimer/"+idASupprimer);
				var product = {_id : ObjectId(""+idASupprimer)};
				db.collection('Panier').remove(product);
				res.setHeader('Access-Control-Allow-Origin','*');
				res.setHeader('Content-Type','text/plain');
				var json = JSON.stringify(product);
				res.end(json);
				});


       assert.equal(null,err);
	app.get('/products/marques/',function(req,res){
				var marqueAChercher = req.params.marque;
				console.log("serveur node : /products/marque/"+marqueAChercher);
				var search = {};
				db.collection('Produits').distinct('marque',function(err, cursor) {

					res.setHeader('Access-Control-Allow-Origin','*');
					res.setHeader('Content-Type','application/json');

					var json = JSON.stringify(cursor);
					res.end(json);
					})
		});


		app.get('/products/types/',function(req,res){
					var typeAChercher = req.params.marque;
					console.log("serveur node : /products/types/-");
					var search = {};
					db.collection('Produits').distinct('type',function(err, cursor) {

						res.setHeader('Access-Control-Allow-Origin','*');
						res.setHeader('Content-Type','application/json');

						var json = JSON.stringify(cursor);
						res.end(json);
		  			})
			});

	app.get('/',function(req,res){
				res.setHeader('Content-Type','text/plain');
				res.end('hello');
	});

	app.get('/products',function(req,res){
				res.setHeader('Content-Type','text/plain');
				res.end('hello');
	});

});









app.listen(8000);
