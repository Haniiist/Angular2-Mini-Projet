"use strict";
var router_1 = require("@angular/router");
var appRoutes = [];
exports.appRoutingProviders = [];
exports.routing = router_1.RouterModule.forRoot(appRoutes);
//# sourceMappingURL=app.routing.js.map