import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';
import {PrincipalModule}  from './app.module';



platformBrowserDynamic().bootstrapModule(PrincipalModule);
