import {Component} from '@angular/core';

@Component({
	selector: 'menu',
	templateUrl: 'templates/menu.html',
	styleUrls: ['styles/menu.css']
	})

export class MenuComponent{
       titre = 'Recherche sur les produits';
       marque :string = 'Fender';
			 type :string = 'Guitare Electrique';
			 SearchParameterType = " ";
			 SearchParameterMarque = true;

       setMarque(value :string){
       		       this.marque=value;
		       }
					 setType(value :string){
		       		       this.type=value;
				       }
					 setRecherche(value :string){
											this.SearchParameterType=value;
							}
		       }
