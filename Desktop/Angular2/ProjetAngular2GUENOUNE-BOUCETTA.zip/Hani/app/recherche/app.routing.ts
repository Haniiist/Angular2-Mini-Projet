import {ModuleWithProviders} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {RechercheMarquesComponent} from './RechercheMarques.component';
import {RechercheTypesComponent} from './RechercheTypes.component';
import {RechercheParMarqueComponent} from './RechercheParMarque.component';
import {RechercheParTypeComponent} from './RechercheParType.component';


const appRoutes: Routes = [
{ path: 'rechercheMarques', component: RechercheMarquesComponent },
{ path: 'rechercheTypes', component: RechercheTypesComponent },
{ path: 'rechercheParMarque/:marque', component: RechercheParMarqueComponent },
{ path: 'rechercheParType/:type', component: RechercheParTypeComponent },


];

export const appRoutingProviders: any[] = [ ];

export const RechercheRouting: ModuleWithProviders = RouterModule.forRoot(appRoutes);
