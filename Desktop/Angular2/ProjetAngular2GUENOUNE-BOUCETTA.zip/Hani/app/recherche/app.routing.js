"use strict";
var router_1 = require("@angular/router");
var RechercheMarques_component_1 = require("./RechercheMarques.component");
var RechercheTypes_component_1 = require("./RechercheTypes.component");
var RechercheParMarque_component_1 = require("./RechercheParMarque.component");
var RechercheParType_component_1 = require("./RechercheParType.component");
var appRoutes = [
    { path: 'rechercheMarques', component: RechercheMarques_component_1.RechercheMarquesComponent },
    { path: 'rechercheTypes', component: RechercheTypes_component_1.RechercheTypesComponent },
    { path: 'rechercheParMarque/:marque', component: RechercheParMarque_component_1.RechercheParMarqueComponent },
    { path: 'rechercheParType/:type', component: RechercheParType_component_1.RechercheParTypeComponent },
];
exports.appRoutingProviders = [];
exports.RechercheRouting = router_1.RouterModule.forRoot(appRoutes);
//# sourceMappingURL=app.routing.js.map