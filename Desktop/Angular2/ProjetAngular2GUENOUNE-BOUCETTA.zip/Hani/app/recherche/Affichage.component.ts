import {Component, Input} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { RechercheService } from './Recherche.service';

@Component({
	selector: 'Affichage',
	templateUrl: 'templates/Affichage.html',
	styleUrls: ['styles/menu.css']
})

export class AffichageComponent {
@Input() items :any;
item ="Some value"
public selectedStyle = "Style";
public selectedType = "Type";
public selectedBrand = "Marque";

setItems(value :any){
					this.items=value;
		}


}
