"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var MenuComponent = (function () {
    function MenuComponent() {
        this.titre = 'Recherche sur les produits';
        this.marque = 'Fender';
        this.type = 'Guitare Electrique';
        this.SearchParameterType = " ";
        this.SearchParameterMarque = true;
    }
    MenuComponent.prototype.setMarque = function (value) {
        this.marque = value;
    };
    MenuComponent.prototype.setType = function (value) {
        this.type = value;
    };
    MenuComponent.prototype.setRecherche = function (value) {
        this.SearchParameterType = value;
    };
    return MenuComponent;
}());
MenuComponent = __decorate([
    core_1.Component({
        selector: 'menu',
        templateUrl: 'templates/menu.html',
        styleUrls: ['styles/menu.css']
    })
], MenuComponent);
exports.MenuComponent = MenuComponent;
//# sourceMappingURL=Menu.component.js.map