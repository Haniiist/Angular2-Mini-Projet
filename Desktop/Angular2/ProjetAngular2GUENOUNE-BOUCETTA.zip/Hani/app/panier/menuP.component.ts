import {Component} from '@angular/core';

@Component({
	selector: 'menuP',
	templateUrl: 'templates/menuP.html',
	styleUrls: ['styles/menu.css']
	})

export class MenuPComponent{
       titre = 'Panier';

		       }
