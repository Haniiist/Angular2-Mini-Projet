import {Component, OnInit} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { PanierService } from './Panier.service';

@Component({
	templateUrl: 'templates/AfficherPanier.html',
styleUrls: ['styles/menu.css']
})

export class AfficherPanierComponent {
	public items :any;
	       public constructor(private recherche :PanierService) {}

	  ngOnInit() {

	                    this.recherche.getJSON("afficher")
			    .subscribe(res => this.items = res,
	       				       err => console.error(err),
	       				       	   () => console.log('done'));

	}

}
