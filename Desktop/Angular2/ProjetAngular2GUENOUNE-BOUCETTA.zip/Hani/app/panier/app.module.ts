import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';


import { PanierRouting, appRoutingProviders }  from './app.routing';
import { PanierService }  from './Panier.service';
import { AjouterPanierComponent } from './AjouterPanier.component';
import { SupprimerPanierComponent } from './SupprimerPanier.component';
import { AfficherPanierComponent } from './AfficherPanier.component';
import { MenuPComponent } from './menuP.component';

@NgModule({
  imports:      [ BrowserModule, HttpModule,PanierRouting ],
  declarations: [ MenuPComponent,SupprimerPanierComponent,AfficherPanierComponent,AjouterPanierComponent ],
  providers:    [ PanierService ],
  bootstrap:    [ MenuPComponent ],
  exports:      [ MenuPComponent ]
})
export class ModulePanier { }
