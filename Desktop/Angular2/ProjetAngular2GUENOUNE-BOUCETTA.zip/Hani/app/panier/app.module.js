"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var http_1 = require("@angular/http");
var app_routing_1 = require("./app.routing");
var Panier_service_1 = require("./Panier.service");
var AjouterPanier_component_1 = require("./AjouterPanier.component");
var SupprimerPanier_component_1 = require("./SupprimerPanier.component");
var AfficherPanier_component_1 = require("./AfficherPanier.component");
var menuP_component_1 = require("./menuP.component");
var ModulePanier = (function () {
    function ModulePanier() {
    }
    return ModulePanier;
}());
ModulePanier = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, http_1.HttpModule, app_routing_1.PanierRouting],
        declarations: [menuP_component_1.MenuPComponent, SupprimerPanier_component_1.SupprimerPanierComponent, AfficherPanier_component_1.AfficherPanierComponent, AjouterPanier_component_1.AjouterPanierComponent],
        providers: [Panier_service_1.PanierService],
        bootstrap: [menuP_component_1.MenuPComponent],
        exports: [menuP_component_1.MenuPComponent]
    })
], ModulePanier);
exports.ModulePanier = ModulePanier;
//# sourceMappingURL=app.module.js.map