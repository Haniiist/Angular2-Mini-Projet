import {Component} from '@angular/core';
import {ActivatedRoute} from '@angular/router';
import { PanierService } from './Panier.service';

@Component({
	templateUrl: 'templates/SupprimerPanier.html',
	})

export class SupprimerPanierComponent{
public items :any;
			 public constructor(private recherche :PanierService, private route: ActivatedRoute) {}

	ngOnInit() {
		this.route.params.subscribe(params => {
										this.recherche.getJSON("supprimer/"+params['id'])
										.subscribe(res => this.items = res,
							       				       err => console.error(err),
							       				       	   () => console.log('done'));
				;

});
}
}
