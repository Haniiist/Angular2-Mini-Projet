import {ModuleWithProviders} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {AfficherPanierComponent} from './AfficherPanier.component';
import {AjouterPanierComponent} from './AjouterPanier.component';
import {SupprimerPanierComponent} from './SupprimerPanier.component';



const appRoutes: Routes = [
{ path: 'AfficherPanier', component:AfficherPanierComponent },
{ path: 'AjouterPanier/:id', component: AjouterPanierComponent },
{ path: 'SupprimerPanier/:id', component: SupprimerPanierComponent }
];

export const appRoutingProviders: any[] = [ ];

export const PanierRouting: ModuleWithProviders = RouterModule.forRoot(appRoutes);
