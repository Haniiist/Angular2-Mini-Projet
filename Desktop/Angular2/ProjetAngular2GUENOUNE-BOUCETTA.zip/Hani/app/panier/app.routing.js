"use strict";
var router_1 = require("@angular/router");
var AfficherPanier_component_1 = require("./AfficherPanier.component");
var AjouterPanier_component_1 = require("./AjouterPanier.component");
var SupprimerPanier_component_1 = require("./SupprimerPanier.component");
var appRoutes = [
    { path: 'AfficherPanier', component: AfficherPanier_component_1.AfficherPanierComponent },
    { path: 'AjouterPanier/:id', component: AjouterPanier_component_1.AjouterPanierComponent },
    { path: 'SupprimerPanier/:id', component: SupprimerPanier_component_1.SupprimerPanierComponent }
];
exports.appRoutingProviders = [];
exports.PanierRouting = router_1.RouterModule.forRoot(appRoutes);
//# sourceMappingURL=app.routing.js.map