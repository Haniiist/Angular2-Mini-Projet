import {Component} from '@angular/core';

@Component({
	selector: 'Principal',
	templateUrl: 'templates/Principal.html',
	styleUrls: ['styles/menu.css']
	})

export class PrincipalComponent{
       titre = 'E-commerce---Accueil';
       }
