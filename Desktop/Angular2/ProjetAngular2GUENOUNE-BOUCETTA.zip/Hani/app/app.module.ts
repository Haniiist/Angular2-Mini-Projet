import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpModule } from '@angular/http';

import { routing, appRoutingProviders }  from './app.routing';
import { RechercheService }  from './recherche/Recherche.service';
import { RechercheRouting } from './recherche/app.routing';
import { PanierRouting } from './panier/app.routing';
import { ModuleRecherche } from './recherche/app.module';
import { ModulePanier } from './panier/app.module';

import { PrincipalComponent } from './Principal.component';

@NgModule({
  imports:      [ BrowserModule, HttpModule, routing , ModuleRecherche,ModulePanier,RechercheRouting, PanierRouting],
  declarations: [ PrincipalComponent ],
  providers:    [ RechercheService ],
  bootstrap:    [ PrincipalComponent ]
})
export class PrincipalModule { }
